
<script>
  function blockCopy() {
    alert("Conteúdo Bloqueado");
    return false;
  }
  document.addEventListener("contextmenu", blockCopy);
  document.addEventListener("keydown", function (e) {
    if (e.ctrlKey && (e.key === "c" || e.key === "C")) {
      blockCopy();
    }
  });
</script>

